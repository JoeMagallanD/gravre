---
title: Placeholder Slides Title
---

[.text: alignment(center)]

# CPT 363

### Slides Placeholder

> “A work in progress. And the possibilities are endless.”
-- Elizabeth Eulberg

---

![fit](https://hibbittsdesign.org/images/ux-toolkit-8-no-numbers.png "Diagram of user experience design process/techniques")

---

[youtube]https://www.youtube.com/watch?v=Nj6x01wg2WA[/youtube]

---

# Topics to Explore
1. Topic One  
2. Topic Two   
3. Topic Three  

---

# Slides Placeholder

### Topic One

---

# Slides Placeholder

### Topic Two

---

# Slides Placeholder

### Topic Three

---

# Summary
1. Topic One  
2. Topic Two   
3. Topic Three  
