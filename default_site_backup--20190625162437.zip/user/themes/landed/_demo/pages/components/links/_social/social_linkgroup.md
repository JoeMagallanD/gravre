---
links:
    - target: '#'
      label: 'Twitter'
      icon: twitter
    - target: '#'
      label: 'Facebook'
      icon: facebook
    - target: '#'
      label: 'LinkedIn'
      icon: linkedin
    - target: '#'
      label: 'Instagram'
      icon: instagram
    - target: '#'
      label: 'Github'
      icon: github
    - target: '#'
      label: 'Email'
      icon: envelope
---
