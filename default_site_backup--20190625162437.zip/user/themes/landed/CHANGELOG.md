# v0.1.0
##  24-09-2018

1. [](#new)
    * initial basic port of [existing theme](https://html5up.net/landed)

# v0.1.1
##  20-10-2018

1. [](#bugfix)
    * correct link for non-default hero images in base template

# v0.1.2
##  24-05-2019

1. [](#improved)
    * Base template modified so it can be extended to support a deferred asset block ([#3](https://github.com/hughbris/grav-theme-landed/issues/3))

1. [](#new)
    * Instructions for deploying deferred asset blocks added to README
    * custom default favicon for theme
