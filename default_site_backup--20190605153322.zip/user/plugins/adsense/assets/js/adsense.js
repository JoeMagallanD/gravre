$(window).load(function(){
  setTimeout(function(){
    $('ins.adsbygoogle').each(function(){
      (adsbygoogle = window.adsbygoogle || []).push({});
    });
  }, 1400);
});
