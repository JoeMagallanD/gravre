# v1.1.1

## 18/06/2017

1.  [](#change)

-   Restore english version

# v1.1.0

## 08/06/2017

1.  [](#new)

-   Changed processing from pure echo to the use of shortcode
-   Fixed a bug with sandbox mode

# v1.0.2

## 16/03/2016

1.  [](#new)

-   Added optional modular slot id
-   Fixed a bug with sandbox mode

# v1.0.1

## 05/12/2015

1.  [](#new)

-   Added Sandbox mode for testing purpose
-   Added pseudo placeholder image until ad is loaded

# v1.0.0

## 25/11/2015

1.  [](#new)

-   ChangeLog started...
