---
title: Intermediate
taxonomy:
    category: docs
child_type: docs
---

### Chapter 2

# Intermediate

Delve deeper into more **complex** topics
