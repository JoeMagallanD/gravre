---
title: Embedded Presentation
taxonomy:
    category: docs
---

Example Embedded Presentation  
[presentation="presentations/placeholder-slides"]
