---
title: 'Left Sidebar'
teaser: 'Ipsum dolor feugiat aliquam tempus sed magna lorem consequat accumsan'
hero_image: 'images/pic05.jpg'
# hero_alt: 'a kind of void'
taxonomy:
  pagetype: feature
spotlight:
  image: 'images/pic03.jpg' # spotlight.jpg
  headline: 'Interdum amet non magna accumsan'
  subheading: 'Nunc commodo accumsan eget id nisi eu col volutpat magna'
  blurb: 'Feugiat accumsan lorem eu ac lorem amet ac arcu phasellus tortor enim mi mi nisi praesent adipiscing. Integer mi sed nascetur cep aliquet augue varius tempus lobortis porttitor lorem et accumsan consequat adipiscing lorem.'
  # button:
  #  text: 'Learn More'
sidebars:
  portals:
    - path: '/dummy/magna'
      # button_text: 'MOAR'
      words: 33
    - path: '/dummy/amet'
      # button_text: 'MOAR!'
      # words: 33
---

### Dolore Amet Consequat

Aliquam massa urna, imperdiet sit amet mi non, bibendum euismod est. Curabitur mi justo, tincidunt vel eros ullamcorper, porta cursus justo. Cras vel neque eros. Vestibulum diam quam, mollis at magna consectetur non, malesuada quis augue. Morbi tincidunt pretium interdum est. Curabitur mi justo, tincidunt vel eros ullamcorper, porta cursus justo. Cras vel neque eros. Vestibulum diam.

Vestibulum diam quam, mollis at consectetur non, malesuada quis augue. Morbi tincidunt pretium interdum. Morbi mattis elementum orci, nec dictum porta cursus justo. Quisque ultricies lorem in ligula condimentum, et egestas turpis sagittis. Cras ac nunc urna. Nullam eget lobortis purus. Phasellus vitae tortor non est placerat tristique.

### Sed Magna Ornare

In vestibulum massa quis arcu lobortis tempus. Nam pretium arcu in odio vulputate luctus. Suspendisse euismod lorem eget lacinia fringilla. Sed sed felis justo. Nunc sodales elit in laoreet aliquam. Nam gravida, nisl sit amet iaculis porttitor, risus nisi rutrum metus.

* Faucibus orci lobortis ac adipiscing integer.
* Col accumsan arcu mi aliquet placerat.
* Lobortis vestibulum ut magna tempor massa nascetur.
* Blandit massa non blandit tempor interdum.
* Lacinia mattis arcu nascetur lobortis.
