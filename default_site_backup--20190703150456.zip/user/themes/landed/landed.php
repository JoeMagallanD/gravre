<?php
namespace Grav\Theme;

use Grav\Common\Theme;

class Landed extends Theme
{
    // Access plugin events in this class
}
